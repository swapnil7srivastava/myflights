# Japan flights V3.1: BLR ⇄ Japan, 2 adults, Economy, INR (cash + Amex MR)
Searched 31 Oct 2026, ~17:41–19:35 IST. Source: Fli 0.9.0 (Google Flights data), `adults=2` (party totals). OctoTrip not used. **Every price is a Google quote from one session, not checkout-verified. Baggage is UNVERIFIED on every itinerary, so none is QUALIFIED.** Nothing was booked and no points were moved.

## Decision summary
1. **Cheapest qualified cash flight:** NONE. Baggage and checkout price are unverified everywhere.
2. **Cheapest provisional:** **₹132,238 for 2 (₹66,119 each)**, Cathay Pacific both ways, 15 Mar → 26 Mar 2027, 11 Japan nights. Same price on 14 Mar → 25 Mar and 15 Mar → 24/25 Mar. Re-queried at 19:3x IST with the same price.
3. **Under ₹140,000:** the CX fare above (7 date/flight variants at ₹132,238, plus ₹137,876 for 14 → 25 Mar). It is **mid-March, before your sakura window**. Details below.
4. **Best cash + miles:** none worthwhile (see `cash_vs_miles.md`).
5. **Fastest/value:** same CX itinerary, 10h20 out and 13h20 back.
6. **Best March sakura-window option:** **₹148,840** (23 Mar → 1/2/6 Apr), JL754 + GK213 via NRT out (12h25), JL753 nonstop back (9h30). Use the GK211 variant (4h40 NRT layover, same price) if the 2h55 connection worries you. ₹8,840 over budget.
7. **Best April savings:** ₹144,812, Thai via BKK, 26 Apr → 7 May (late April, after typical bloom).
8. **Amex points:** save them for Taj (use none). Details in `cash_vs_miles.md`.
9. **Verification links (manual):** Google Flights → Multi-city; cathaypacific.com, japanairlines.com, thaiairways.com. I have no verified deep links, since Fli returns none.
10. **Unverified:** checked baggage everywhere, ticket protection, checkout prices and taxes, award inventory, bloom timing.
- **Against the historical Air India ₹139,820 (21 Mar → 5 Apr, a historical app fare, not reproduced today):** the CX fare is ₹7,582 lower but a different season, airline and dates. For the same 21 Mar → 5 Apr dates the best current quote is ₹202,314.

## Table A: Top cheapest cash itineraries (≤16h each way, 9–14 nights; party totals, Economy)
| # | Dates (out → ret) | Direction | Nights | Airlines | Stops | Out h | Ret h | Bags | Total INR (2) | Status |
|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 15 Mar → 26 Mar | Osaka-first | 11 | CX624+CX506 / CX527+CX623 | 1/1 | 10.3 | 13.3 | UNVERIFIED | 132,238 | PROVISIONAL, re-queried |
| 2 | 14 Mar → 25 Mar | Osaka-first | 11 | CX624+CX598 / CX527+CX623 | 1/1 | 12.8 | 13.3 | UNVERIFIED | 132,238 | PROVISIONAL |
| 3 | 15 Mar → 24 / 25 Mar | Osaka-first | 9 / 10 | CX / CX | 1/1 | 10.3 | 13.3 | UNVERIFIED | 132,238 | PROVISIONAL |
| 4 | 16 Mar → 27 Mar | Osaka-first | 11 | CX624+CX598 / CX527+CX623 | 1/1 | 12.8 | 13.3 | UNVERIFIED | 141,026 | PROVISIONAL |
| 5 | 26 Apr → 7 May | Osaka-first | 11 | TG326+TG672 / TG643+TG325 | 1/1 | 11.5 | 15.4 | UNVERIFIED | 144,812 | PROVISIONAL |
| 6 | 10 May → 21 May | Osaka-first | 10 | TG356+TG622 / TG643+TG325 | 1/1 | 12.2 | 15.4 | UNVERIFIED | 144,812 | PROVISIONAL |
| 7 | 10 Mar → 21 Mar | Osaka-first | 11 | CX / CX | 1/1 | 10.3 | 13.3 | UNVERIFIED | 146,802 | PROVISIONAL |
| 8 | 23 Mar → 2 Apr | Osaka-first | 10 | JL754+GK213 / JL753 | 1/0 | 12.4 | 9.5 | UNVERIFIED | 148,840 | PROVISIONAL, re-queried |
| 9 | 23 Mar → 1 Apr / 6 Apr | Osaka-first | 9 / 14 | JL754+GK213 / JL753 | 1/0 | 12.4 | 9.5 | UNVERIFIED | 148,840 | PROVISIONAL |
| 10 | 29 Mar → 7/8/9 Apr | Osaka-first | 9–11 | JL754+JL229 / JL753 | 1/0 | 15.6 | 9.5 | UNVERIFIED | 149,068 | PROVISIONAL; JL229 departs from Haneda, so there is an NRT→HND airport change |
| 11 | 12 Apr → 23 Apr | Osaka-first | 11 | JL754+JL229 / JL753 | 1/0 | 15.6 | 9.5 | UNVERIFIED | 149,068 | PROVISIONAL |
| 12 | 22 Mar → 2 Apr | Tokyo-first reverse | 10 | TG356+TG682 / TG623+TG325 | 1/1 | 11.2 | 15.7 | UNVERIFIED | 161,512 | best Tokyo-first found |

All 5 Apr returns cost far more: best current 5 Apr quotes are ₹174,642 (24 Mar → 5 Apr; DURATION EXCEPTION at 16h50 and 17h50) and ₹178,556 (23 Mar → 5 Apr).

## Table B: Under-₹140,000 candidates (ALL PROVISIONAL, none qualified)
| # | Dates | Total INR (2) | Airlines | Out/back | Baggage | Protection | Link | Confidence |
|---|---|---|---|---|---|---|---|---|
| 1 | 15 Mar → 26 Mar (11n) | 132,238 | CX only | 10h20 / 13h20 | UNVERIFIED | single airline itinerary; 95-min HKG connection out, 110-min back, not confirmed protected | none verified | PROVISIONAL, re-queried same price |
| 2 | 14 Mar → 25 Mar (11n) | 132,238 | CX only | 12h50 / 13h20 | UNVERIFIED | longer 4h10 HKG layover out | none verified | PROVISIONAL |
| 3 | 15 Mar → 24/25 Mar (9/10n) | 132,238 | CX only | 10h20 / 13h20 | UNVERIFIED | same | none verified | PROVISIONAL |
| 4 | 14 Mar → 25 Mar | 137,876 | CX only | 10h20 / 13h20 | UNVERIFIED | same | none verified | PROVISIONAL |

Sakura caution: these are **mid-March**. Typical (historical) bloom in Tokyo, Kyoto and Osaka is late March to early April. I have not checked 2027 forecasts, so mid-March may be early. This fare is cheapest irrespective of sakura, not a sakura-priority itinerary. Tokyo-first reverse of the same dates (BLR→HND/NRT, KIX→BLR): ₹132,802 (15 → 26 Mar).

## Table C: Cash + Amex options (details in `cash_vs_miles.md`)
| # | Programme | Dates | MR required | Out-of-pocket | Effective cost @0.60 | ₹/MR | Award availability | Verdict |
|---|---|---|---|---|---|---|---|---|
| 1 | Virgin → ANA HND→DEL (return, 2 pax), illustrative | 5 Apr | 56,250 (45,000 VP, indicative) | ≥110,994 excl. taxes and all bags | ≥144,744 | ≤1.46 (before taxes; fair comparable) | NOT_ESTABLISHED (phone booking) | Reject: not cheaper than all-cash ₹132,238 even at ₹0.50/MR |
| 2 | KrisFlyer (2:1), SQ outbound | Mar | 4 × miles per adult | n/a | n/a | break-even ≤42,299 miles/adult | NOT_ESTABLISHED | MANUAL_VERIFICATION_REQUIRED |
| 3 | Asia Miles (2:1), CX outbound | mid-Mar | 4 × miles per adult | n/a | n/a | break-even ≤42,299 miles/adult | NOT_ESTABLISHED | MANUAL_VERIFICATION_REQUIRED |
| 4 | BA/Qatar Avios (2:1), JL/CX | Mar–Apr | 4 × Avios per adult | n/a | n/a | n/a | NOT_ESTABLISHED | MANUAL_VERIFICATION_REQUIRED |

## Table D: Best dates by period (≥9–14 nights, ≤16h)
| Period | Best total | Dates | Nights | Hours out/back | Bags | Sakura suitability | Price status |
|---|---|---|---|---|---|---|---|
| Mid-March (Phase D) | 132,238 | 15→26 Mar | 11 | 10.3 / 13.3 | UNVERIFIED | probably early (historical averages only) | re-queried |
| March sakura window (20–30 Mar) | 148,840 | 23 Mar→1/2/6 Apr | 9–14 | 12.4 / 9.5 | UNVERIFIED | good (historical) | re-queried |
| Early April (31 Mar–12 Apr out) | 149,068 | 12 Apr→23 Apr | 11 | 15.6 / 9.5 | UNVERIFIED | likely past peak for Tokyo/Osaka | single quote |
| Mid April (13–22 Apr out) | 158,214 | 20 Apr→1 May | 11 | 10.4 / 12.8 | UNVERIFIED | low | single quote |
| Late April (23–30 Apr out) | 144,812 | 26 Apr→7 May | 11 | 11.5 / 15.4 | UNVERIFIED | none expected | single quote |
| May fallback | 144,812 | 10→21 May | 10 | 12.2 / 15.4 | UNVERIFIED | none | single quote |

Phase B and C (April) were **sampled** at 3–4-day intervals with an 11-night stay, not exhaustively. Phase D covered only 10–19 Mar and 2–15 May samples.

## Table E: Provider and airline coverage
| Provider/airline | Searches | Results | Limits |
|---|---|---|---|
| Fli multi-city (2 adults, HND+NRT return) | 135 query files | itineraries from CX, JL+GK, JL, TG, AI, NH, SQ, TG, AirAsia, etc. | Google data; many itineraries unpriced; price may differ at checkout |
| Fli one-way 2 adults (≤16h) | 49 files | legs and positioning fares | no bag pricing |
| Fli one-way 1 adult (first sweep) | 35 files | 1-adult prices | superseded by 2-adult data |
| Indian gateways DEL/BOM/MAA/HYD/COK/CCU | 12 multi-city + 12 positioning | all > BLR; COK no priced result | 2 date pairs only |
| Japan: KIX vs NGO arrival | KIX main; 1 NGO test | NGO ₹148,768 (no saving) | ITM/UKB not checked |
| Air India | targeted tests | mostly unpriced in Fli; not reproducible | benchmark fares not found |
| Amex/airline award sites | web research only | no inventory | logins and phone bookings required |
| Peach, ZIPAIR, Scoot, EVA, China Airlines, others | not searched directly | n/a | NOT_YET_CHECKED |

## Coverage metrics (logged, not estimated)
- Date pairs: 110 generated for the 20–30 Mar × 1–10 Apr window; **74 searched** as multi-city (Phase A). In total 104 BLR→KIX date pairs and 7 Tokyo-first pairs were searched, including Phases B–D samples.
- Files: 135 multi-city, 49 two-adult one-way, 35 one-adult one-way = 219 queries attempted. 39 queries are in the timestamped log; 0 logged failures. Two multi-city queries returned nothing.
- Rows in `all_flight_results.csv`: 5,278 observations, 0 qualified, 0 with confirmed baggage, 10 provisional under ₹140,000, 3 finalists re-queried.
- Exhaustive coverage was **not achieved**. The remaining 36 date pairs of Phase A, most of Phases B–D, and most airlines were not searched.

## Corrections and caveats
- The ₹148,840 JAL fare appears only for some outbound/return dates and vanishes for returns on 3–5 Apr.
- JL754+GK213 is on two airlines (JAL then Jetstar Japan). Google's self-transfer flag was False, but protection, bag transfer and immigration time were **not verified**; treat as a possible separate booking until you confirm.
- The NRT→HND airport change on JL229 itineraries needs customs, bag recheck and a ~1.5h+ transfer; not recommended.
- The 'Verified' labels mean "re-queried with the same price", not "bookable".

## What to verify manually (in order)
1. Google Flights → Multi-city: BLR→KIX 15 Mar 2027 and NRT or HND→BLR 26 Mar 2027, 2 adults, Economy. Expect ≈₹132,238. Open the fare and read checked baggage per flight.
2. cathaypacific.com: same dates, 2 adults; confirm baggage (20 kg per adult wanted), taxes and fare conditions.
3. If you need March sakura dates: same check for 23 Mar → 2 Apr (JL754 + GK211/GK213 + JL753) at japanairlines.com.
4. Award check (optional): Singapore KrisFlyer, Cathay Asia Miles, Virgin Flying Club (ANA), BA Avios. Look for 2 economy award seats, miles per adult and taxes.

---
# V3.2 addendum: trip windows, season and office leave (31 Oct 2026)
Full data: `results/best_trip_dates.csv` (566 windows, 9–12 calendar days). Leave rules: Sat/Sun off; departure before 06:00 means leaving the previous evening after work; arrival on a weekday counts as leave; employer holiday calendars were NOT provided, so confirmed company holidays = 0 and both travellers show the same leave. Tentative public holidays (web search, not employer-confirmed): Good Friday 26 Mar, Ugadi 7 or 8 Apr (sources disagree), Ambedkar Jayanti 14 Apr. Japan sightseeing days ≈ Japan nights. Bloom: 30-year full-bloom averages Tokyo ~3 Apr, Kyoto ~4 Apr, Osaka ~5 Apr; JMC's 2026 forecast was Tokyo 26 Mar and Kyoto/Osaka 31 Mar. No 2027 forecast exists yet. Season and weather ratings are my general assessments, not checked this session.

**Key finding:** at 10–11 calendar days, no fare is ≤ ₹140,000 (cheapest ₹141,026, 11 → 21 Mar). Only 12-day windows reach ₹132,238. Sakura-peak 10–11-day windows start at ₹149,068. Autumn 2027 returned no itineraries (NOT YET BOOKABLE).

Recommendations: sakura = JL 23 Mar → 2 Apr ₹148,840 (12 days, 8 leave days with Good Friday tentative, 9 without); cheapest = CX 14 Mar → 25 Mar ₹132,238 (12 days) or 11 → 21 Mar ₹141,026 (11 days, 6 leave); fewest leave = Sat-to-Sat 5 → 14 Mar ₹158,214 (5 leave, covers 9 Mar birthday); points = save for Taj. Everything is PROVISIONAL, with baggage UNVERIFIED.

---
## V3.3/V3.4 addendum: corrected dates and finalists
See `finalists.md`. Best overall provisional: JAL+Jetstar from 23 Mar, ₹148,840 (return 31 Mar, 1 Apr or 2 Apr; 10–12 calendar days, 8–10 Japan nights). The JAL ₹149,068 fare is a 29 Mar departure. Cheapest under budget: Cathay 15 → 24/26 Mar, ₹132,238. No fare is verified. Baggage and single-ticket status remain open; official pages were blocked and fresh re-queries were throttled.
