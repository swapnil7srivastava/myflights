# V3.4 finalists: booking-readiness comparison (31 Oct 2026)
All prices are Google Flights quotes via Fli for 2 adults (party totals), INR, **not checkout prices**. Nothing is VERIFIED: checked baggage, single-ticket status and checkout totals could not be confirmed. Data: `finalists_comparison.csv`.

| Option | India → India | Japan nights | Leave (weekdays) | Flights | Stops / airports | Out / back | Baggage | Single ticket | Total for 2 | Sakura (0–5) | Status |
|---|---|---|---|---|---|---|---|---|---|---|---|
| A1 | Tue 23 Mar 02:45 → Thu 1 Apr 00:55 (10 d) | 8 | 8 (7 if Good Friday is a holiday) | JL754 + GK211 / JL753 | 1 stop NRT (4h40), no airport change / nonstop | 14h10 / 9h30 | UNVERIFIED | UNVERIFIED | 148,840 | 3.6 | PROVISIONAL |
| A2 | 23 Mar → Fri 2 Apr 00:55 (11 d) | 9 | 9 (8) | JL754 + GK213 / JL753 | 1 stop NRT (2h55) / nonstop | 12h25 / 9h30 | UNVERIFIED | UNVERIFIED | 148,840 | 3.8 | PROVISIONAL |
| A3 | 23 Mar → Sat 3 Apr 00:55 (12 d) | 10 | 9 (8) | JL754 + GK213 / JL753 | same | 12h25 / 9h30 | UNVERIFIED | UNVERIFIED | 148,840 | 3.9 | PROVISIONAL |
| B1 | Mon 29 Mar 02:55 → Thu 8 Apr 00:55 (11 d) | 9 | 9 (8 if Ugadi applies) | JL754 + JL229 / JL753 | 1 stop; **NRT→HND airport change**, 6h05 gap / nonstop | 15h35 / 9h30 | UNVERIFIED | UNVERIFIED | 149,068 | 4.0 | PROVISIONAL, higher risk |
| C1 | Mon 15 Mar 01:20 → Thu 25 Mar 00:15 (11 d) | 9 | 9 | CX624+CX506 / CX527+CX623 | 1 stop HKG each way (95 min / 110 min) | 10h20 / 13h20 | UNVERIFIED (Light is normally 1 × 23 kg) | single airline, UNVERIFIED | 132,238 | 1.2 | PROVISIONAL |
| C2 | 15 Mar → Sat 27 Mar 00:15 (13 d) | 11 | 10 (9) | same | same | 10h20 / 13h20 | UNVERIFIED | UNVERIFIED | 132,238 | 1.7 | PROVISIONAL |

**Date correction:** the ₹149,068 fare is a **29 Mar** departure, not 28 Mar. It was labelled from the old date rule.

**No-airport-change comparable for B:** the cheapest 10–11-day option departing 26–30 Mar with no airport change is Thai (TG356+TG622 / TG641+TG325 via BKK), **₹183,482**, 29 Mar → 7 Apr (home 23:55 on 7 Apr, 12h10 / 16h35). That is **₹34,414 more** than ₹149,068 and outside your ₹150–160k allowance. Cathay, Singapore and Malaysia quotes for those dates were all dearer. The JAL+Jetstar fare itself only exists for departures on or before 23 Mar.

## What was and wasn't verified
- **Schedules (Google data only, not airline-confirmed):** JL754 departs BLR 02:45 for 22–26 Mar and 02:55 for 28–29 Mar. JL753 NRT→BLR departs 18:25 on 24 Mar and 18:55 on 30 Mar–9 Apr, consistent with a spring schedule change around 28 Mar. I did not retrieve JAL's timetable.
- **Single ticket for JL754 + GK213:** JAL's codeshare rule (from a search result; the JAL page itself returned HTTP 403) requires the whole trip on one ticket, with a JAL/Jetstar Japan domestic transit counter in the Narita arrivals area (the result said Terminal 2). You cited Terminal 3. **That discrepancy is unresolved.** Check the JAL pages yourself. An independently sold GK ticket would not carry the same bag benefits.
- **Narita connection:** 2h55 (GK213) is above JAL's published 110-minute minimum for JAL domestic–international at Narita, but that minimum is for JAL flights, not Jetstar Japan. GK211 leaves 4h40, which is safer if bags must be reclaimed and rechecked.
- **Cathay baggage:** third-party guides say Economy Light is 1 × 23 kg, Essential and Flex 2 × 23 kg. The cathaypacific.com page timed out, and none of this proves the fare family on this quote.
- **Airline-direct and provider prices:** Cathay (timeout), JAL (403) and Google Flights (JavaScript page, nothing extractable) could not be read. Fresh re-queries after 20:53 IST returned empty pages, so I stopped. Last matching observations: A at ~18:05, 18:10 and 19:3x IST; C at ~18:5x and 19:25–19:29 IST; B (22 Mar variant) at 18:10 IST, and the 29 Mar variant once at ~19:19 IST.
- **Sakura rating:** a heuristic, not a forecast. Osaka/Kyoto/Nara first (60% of nights), Tokyo last. Bloom windows come from 30-year full-bloom averages (Tokyo ~3 Apr, Kyoto ~4 Apr, Osaka ~5 Apr) in a normal year and an 8-days-early year, averaged. No 2027 forecast exists.
- **Leave:** weekends off; public holidays (Good Friday 26 Mar, Ugadi 7 or 8 Apr) are tentative and not employer-confirmed. Both travellers show the same number until you share each employer's calendar.

## Picks
- **Best overall:** A (₹148,840). No airport change, a nonstop return, good bloom coverage if bloom runs early. Choose A1 for less leave or A3 for more time.
- **Best sakura window:** tie. B1 scores 4.0 (4.5 normal year, 3.5 early) and A3 3.9 (2.7 normal, 5.0 early). A avoids the airport change.
- **Best under-budget fallback:** C1 ₹132,238, but sakura only 1.2. It is likely too early for blossoms.
- **Lowest-risk connection:** C (one airline, one ticket, no bag recheck), though its 95-minute HKG connection out is short.
- **Best for office leave:** A1, 8 weekdays (7 if Good Friday applies).

## Shortest manual checklist
1. japanairlines.com, 2 adults, Economy: BLR → KIX 23 Mar via NRT (JL754 + GK211 or GK213) and NRT → BLR 31 Mar or 2 Apr (JL753) as one ticket. Confirm the price, checked bags per adult, the one-ticket status, and where to reclaim and recheck bags at Narita.
2. cathaypacific.com, same method for 15 Mar → 24 Mar, to see the fare family and bag allowance.
3. If A passes, I'd choose A1 or A3 depending on your leave.
