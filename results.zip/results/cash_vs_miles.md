# Cash vs Amex MR (India card), 180,000 MR, Taj alternative ₹0.60/MR (unverified) = ₹108,000
Ratios are indicative: Virgin 5:4 (reported 18 Aug 2026), KrisFlyer / Asia Miles / BA and Qatar Avios 2:1 (a guide verified July 2026; not confirmed on this account). Etihad Guest was removed on 1 Jul 2026. Air India is not a transfer partner. No transfer was made and none should be made before checking the live Amex India partner page.

## Baseline (all cash, no MR)
- Best cash (provisional): **₹132,238**, 15 → 26 Mar, CX/CX. Effective cost ₹132,238; MR remaining 180,000.
- Taj opportunity value of the 180,000 MR: ₹90,000 @0.50, ₹104,940 @0.583, ₹108,000 @0.60.

## Scenario with real cash numbers: Virgin → ANA return (illustrative)
Both adults fly HND→DEL on ANA with 22,500 Virgin points each one-way (third-party chart), then DEL→BLR on a separate ticket; the outbound stays cash (FD138+XJ610, 25 Mar, ₹90,122 for 2).
| Item | Amount |
|---|---|
| MR consumed (45,000 VP ÷ 0.8) | 56,250 (remaining 123,750) |
| Cash out-of-pocket (lower bound) | 90,122 + 20,872 = **₹110,994**, plus award taxes UNKNOWN and all bags UNKNOWN |
| Effective cost @0.50 / 0.583 / 0.60 | 139,119 / 143,788 / **144,744** |
| vs all-cash ₹132,238 | worse at every sensitivity |
| ₹ per MR (against the cheapest practical cash return replaced: NRT TG643+TG325 ₹102,876, minus ₹20,872 positioning, before taxes) | ≤ 1.46 |
Inventory: NOT_ESTABLISHED (Virgin books ANA by phone). Verdict: **reject**. It lowers the bank payment but not the effective cost, and adds a separate ticket and a positioning flight.

## Break-even for the other programmes (no mileage price found)
Replacing the CX outbound for 2 (cash comparable ₹101,518) needs fewer than **42,299 miles per adult** to reach ₹0.60/MR (43,531 at ₹0.583; 50,759 at ₹0.50), before award taxes. Even then, the all-cash CX round trip at ₹132,238 is already under budget, so using points would only help if it also lowers the effective cost below that. Mileage prices and award space for BLR–Japan on SQ, Cathay and JAL via Avios were **not retrieved** (logins required).

## Verdict
**Save the points for Taj.** No award is shown to beat ₹132,238 effective cost, and none has verified inventory. MANUAL_VERIFICATION_REQUIRED list is in `award_opportunities.csv`.
