# Search audit (31 Oct 2026, IST)

## Method and tools
- Fli 0.9.0 in `.venv`. The CLI has no passengers flag, so the Python API was used for `PassengerInfo(adults=2)`.
- Price basis test (BLR/KIX + HND/BLR, 25 Mar / 5 Apr): 1 adult ₹94,875, 2 adults ₹189,750, so the figure is a party total.
- Multi-city search works through `build_multi_city_segments`; the return segment accepted HND + NRT together.
- `max_duration=960` was set on API searches; results were also filtered to ≤16h per leg locally.
- Bag filter: `bags=1` gave the same prices as `bags=0`; `bags=2` gave no results. Treated as unreliable.
- Airline filter (Air India): itineraries returned with price `None`.

## Searches run (approximate; each multi-city query makes about 5–7 HTTP requests)
| Batch | Count | Time (IST) |
|---|---|---|
| One-way CLI, 1 adult: BLR→KIX 22–28 Mar, HND→BLR and NRT→BLR 2–8 Apr, ≤1 stop | 21 | 17:41–17:44 |
| One-way CLI: business (4), gateways BOM/DEL (8) | 12 | 17:44 |
| Re-verification of finalists | 6 | 17:44–17:45 |
| API one-ways, 2 adults, bags=1, ≤16h: BLR→KIX 20–30 Mar, HND→BLR and NRT→BLR 1–10 Apr; bag test | 37 | 17:54–17:55 |
| Multi-city, 2 adults, 5 outbound × 4 return | 20 | 17:57–18:01 |
| Multi-city, 4 outbound × 6 return, plus 4 more | 28 | 18:02–18:10 |
| Multi-city re-verification (3 finalists) | 3 | 18:10 |
| Multi-city, 6 India gateways × 2 date pairs | 12 | ~18:11–18:13 |
| Gateway positioning one-ways, 2 adults | 12 | ~18:13 |
| Air India targeted tests (multi + one-way), NGO, multi test | ~8 | 17:5x–18:14 |

Raw data: `results/raw/` (first sweeps, 1 adult), `results/raw/v2/` (2-adult API results, `MC-*` = multi-city), `results/raw/v2/first/` (first run of re-verified finalists).

## Re-verification
- 23 Mar → 2 Apr (₹148,840), 23 Mar → 6 Apr (₹148,840), 22 Mar → 6 Apr (₹149,068): second run matched the first exactly.
- Others were not re-run.

## Failures and limits
- OctoTrip: not used (no `.mcp.json`, no tools; endpoint fetch timed out).
- Unpriced Fli results: many itineraries (including most Air India) came back without prices. My first summaries dropped them silently.
- `get_booking_options` rejected by Google; no booking links.
- Not searched: most of the 7×7 and extended-window date pairs as multi-city, business class in this pass, ITM/UKB/other Japan airports, baggage fees, overnight positioning costs, Japan domestic transfers.
- No booking or payment was made.

## V3 / V3.1 additions (31 Oct 2026, 19:07–19:40 IST)
- Offline tools: `rank.py` (date matrix + shortlist), `build_db.py` (append-only `all_flight_results.csv`, qualified/best CSVs, `search_progress.json`; atomic writes).
- Batches: Phase A priority grid (24–29 Mar × 4–9 Apr, cap 17h55), reverse Tokyo-first (7 pairs), Phase B April (7 samples), Phase C April (6), Phase D (10 Mar–19 Mar and May, 11 samples), neighbours of the cheap CX fare (10), two fresh re-queries. Logged in `results/raw/v2/_queries.log` (39 OK, 0 FAIL).
- Empty results: 15 Mar → 27 Mar and 12 Mar → 23 Mar returned no itineraries; COK gateway returned no priced result.
- Web research (standard search only): Amex India partner ratios, Virgin–ANA and Asia Miles indicative award prices. KrisFlyer BLR–Japan pricing not found. No award inventory could be checked (logins/phone). No sites were scraped beyond Fli and standard web searches.
- Not completed: 36 of 110 Phase A pairs; most of Phases B–D; baggage verification; most airlines on the checklist.

## V3.2 (31 Oct 2026, ~19:50–20:15 IST)
- 25 new multi-city queries anchored on Fridays (5 Mar–21 May 2027), Sat-out and Fri-out, return Sat of the next-next weekend; 3 autumn 2027 probes returned 0 itineraries (NOT YET BOOKABLE or not returned). 1 other query (14 May → 22 May) returned 0. 0 logged failures.
- `trips.py` computes calendar days, Japan nights, leave and season into `results/best_trip_dates.csv`. Holiday data: web search only, not employer-confirmed. No weather/forecast data was fetched beyond one weak search.

## V3.3 / V3.4 (31 Oct 2026, ~20:50–21:20 IST)
- Calendar rule corrected: calendar days = India departure date to India arrival date inclusive, Japan nights = Japan arrival date to Japan departure date. Old rows kept in `best_trip_dates.csv` with `calc_version = V3.2_SUPERSEDED...`.
- Gap batch: 14 late-March date pairs queried. 9 returned fares; from 20:53:33 onward queries returned empty pages in ~1.5 s (throttling), including 5 gap pairs, 4 Tokyo-first checks and 3 finalist re-queries. A 7-minute cool-down did not clear it, so I stopped. Empty responses are in `results/raw/v2/empty_responses/` (not counted as fares). Pairs still unsearched: 25 and 26 Mar → 3 Apr, 30 Mar → 7/8/9 Apr, and Tokyo-first re-checks.
- Blocked or unusable sources: cathaypacific.com (timeout), jal.co.jp (HTTP 403), Google Flights page (JavaScript, nothing parseable). Not worked around.
- New file: `results/finalists_comparison.csv`, `results/finalists.md`. New scripts: `finalists.py`.
