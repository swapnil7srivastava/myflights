# Airline coverage matrix (Fli / Google Flights data, 31 Oct 2026)

Best price here = lowest one-way fare per adult seen on BLR→KIX or HND/NRT→BLR (≤16h, 1-adult sweep, March 22–28 / April 2–8), which are not multi-city prices. "n/p" = itineraries seen, but none priced within 16h. Baggage is UNVERIFIED for every airline; nothing here shows allowances.

| Airline | Route checked | Result | Within 16h | Baggage | Best price (per adult) | Source |
|---|---|---|---|---|---|---|
| Japan Airlines (JL) | BLR→NRT→KIX, NRT→BLR | seen; best multi-city fares found | yes | UNVERIFIED | 60,064 one-way; JAL multi-city inside ₹148,840 total for two | Fli |
| Jetstar Japan (GK) | NRT→KIX connection | seen (GK213, GK211) | yes | UNVERIFIED | in JAL fare | Fli |
| Cathay Pacific | BLR→HKG→KIX, NRT/HND→HKG→BLR | seen | yes | UNVERIFIED | 50,759 | Fli |
| Thai Airways | via BKK both ways | seen | yes (≤15h25) | UNVERIFIED | 51,438 | Fli |
| Thai AirAsia / AirAsia X | BLR→DMK→KIX | seen | yes (15h35) | UNVERIFIED | 45,061 | Fli |
| VietJet | via SGN / HAN | seen | no (≥24h return) | UNVERIFIED | n/p | Fli |
| Air India | BLR→DEL→KIX, HND→DEL/BOM→BLR | seen, **mostly unpriced** | yes (14h00–15h45) | UNVERIFIED | 182,122 (priced HND→BLR) | Fli |
| IndiGo | domestic legs; 6E on DEL→BLR | seen | yes | UNVERIFIED | 184,483 (as part of JL/6E) | Fli |
| Air India Express | seen only | UNVERIFIED | n/a | UNVERIFIED | n/p | Fli |
| ANA | HND→DEL / SIN | seen | yes | UNVERIFIED | 182,122 | Fli |
| Singapore Airlines | via SIN | seen | yes | UNVERIFIED | 185,868 | Fli |
| Malaysia Airlines | via KUL | seen | yes | UNVERIFIED | 77,670 | Fli |
| SriLankan | via CMB | seen | check | UNVERIFIED | 52,884 | Fli |
| Etihad, Emirates, Qatar | via Gulf | seen | mostly no | UNVERIFIED | Etihad 102,321 | Fli |
| Vietnam Airlines | seen only | UNVERIFIED | n/a | UNVERIFIED | n/p | Fli |
| Akasa Air, Peach, ZIPAIR, Scoot, Batik Air, Philippine Airlines, Cebu Pacific, EVA, China Airlines, STARLUX, Hong Kong Airlines, HK Express, China Eastern/Southern, Air China, Korean Air, Asiana | not found in any result | NOT FOUND / NOT SEARCHED directly | n/a | n/a | n/a | not searched |

Fli's airline filter returned itineraries with no prices (tested with Air India), so targeted airline searches were not useful. Coverage is **not exhaustive**.

## V3.1 status codes (multi-city, 2 adults, 31 Oct 2026)
SEARCHED_FOUND: Cathay Pacific (mid-Mar fare ₹132,238), Japan Airlines + Jetstar Japan (₹148,840), Thai Airways (₹144,812 late Apr), Air India (found but mostly unpriced), ANA, Singapore Airlines, Thai AirAsia/AirAsia X, IndiGo/6E (positioning).
SEARCHED_NO_RESULT: Air India-only filter (unpriced).
NOT_YET_CHECKED: Peach, ZIPAIR, Scoot, EVA, China Airlines, STARLUX, Korean Air, Asiana, China Eastern/Southern, Air China, Hong Kong Airlines, HK Express, Philippine Airlines, Cebu Pacific, Batik, Vietnam Airlines (seen only as legs).
SOURCE_BLOCKED / NOT_SEARCHABLE: award inventory on every airline (login or phone required).
